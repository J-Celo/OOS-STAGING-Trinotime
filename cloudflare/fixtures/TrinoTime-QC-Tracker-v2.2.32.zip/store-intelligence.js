/* Store Intelligence v1 — Augmoto job-row observation only.
 * Never infer a job's store from the selected dropdown filter.
 * No network requests, no page input, and no task-count mutation.
 */
(() => {
  'use strict';
  if (globalThis.__ttStoreIntelligenceV1) return;
  globalThis.__ttStoreIntelligenceV1 = true;
  const JOB_RE = /\bJOB_[A-Z0-9_-]{4,64}\b/ig;
  const ACTION_RE = /\b(?:NEEDS REVIEW|COMPLETED|IN PROGRESS|PENDING|CREATED DATE|REVIEWED|CANCELLED|SUBMITTED)\b/i;
  const valid = s => typeof s === 'string' && s.length > 3 && s.length <= 120 && !/^select a store|all stores|all|unknown$/i.test(s);
  const clean = s => String(s || '').replace(/\s+/g, ' ').replace(/^[\s\-–|:]+|[\s\-–|:]+$/g, '').trim();
  let timer = 0;
  const lastSent = new Map();
  function extract(row, id) {
    // The Store text is alongside the actual JOB link in the Job ID / Store cell.
    // Never inspect the filter field as a source of job identity.
    const columns = [...row.querySelectorAll(':scope > td, :scope > [role="cell"]')];
    let text = clean(columns[0]?.textContent || '');
    if (!text || !text.includes(id)) {
      const anchor = [...row.querySelectorAll('a')].find(a => clean(a.textContent).toUpperCase() === id);
      if (!anchor) return '';
      text = clean(anchor.parentElement?.textContent || '');
    }
    if (!text.includes(id)) return '';
    const jobs = [...text.matchAll(JOB_RE)].map(m=>m[0].toUpperCase());
    if (jobs.length !== 1 || jobs[0] !== id) return '';
    const after = text.slice(text.indexOf(id) + id.length);
    const store = clean(after.split(ACTION_RE)[0]).slice(0, 120);
    return valid(store) && !/\bJOB_[A-Z0-9_-]+\b/i.test(store) ? store : '';
  }
  function scan() {
    timer = 0;
    const batch = [];
    const rows = document.querySelectorAll('tr, [role="row"]');
    for (const row of [...rows].slice(0, 400)) {
      const matches = [...String(row.textContent || '').matchAll(JOB_RE)].map(m => m[0].toUpperCase());
      if (matches.length !== 1) continue;
      const jobId = matches[0];
      const storeName = extract(row, jobId);
      if (!storeName || lastSent.get(jobId) === storeName) continue;
      lastSent.set(jobId, storeName);
      batch.push({jobId, storeName, source:'augmoto-job-row'});
      if (batch.length >= 80) break;
    }
    if (batch.length) for (const type of ['cat-store-observed', 'cft-store-observed']) {
      try { chrome.runtime.sendMessage({ type, stores:batch }).catch(()=>{}); } catch (_) {}
    }
  }
  function schedule() { if (!timer) timer = setTimeout(scan, 600); }
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', schedule, {once:true});
  else schedule();
  const observer = new MutationObserver(schedule);
  observer.observe(document.documentElement, {childList:true, subtree:true});
  window.addEventListener('popstate', schedule);
  window.addEventListener('pageshow', schedule);
})();
