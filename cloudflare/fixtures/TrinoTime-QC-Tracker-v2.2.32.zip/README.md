# QC Tracker v2.2.32 — Secure Shift Recovery (STAGING QA)

**Install only alongside the matching M2.9.46 staging Worker.** This build adds an explicit, user-confirmed **Recover This Shift (No Reset)** action for a newly installed Tracker when the active shift belongs to a previous browser/device ID.

Open the staging TrinoTime site in a signed-in Agent tab, connect Coverage and Confirmation, click **Sync both now**, then choose **Recover This Shift** when the device-conflict warning appears. Stop Augmoto work until both workflows report success. The server verifies the current Agent/POD, signed bridge, active session/generation, and restores the server-authoritative summary/job/task ledger. Old bridge connections are revoked; records are never reset.

Recovery is deliberately blocked if the new extension already contains its own task/job counts, since combining those totals could double-count. A local pre-recovery backup is retained. If recovery fails halfway, retry **Recover This Shift**; the server keeps a pending handoff until acknowledgment. Do not click Reset Current Shift or clear extension storage.

Coverage and Confirmation retain the compact 168 × 44px minimized HUD, unchanged counting algorithms, Store Intelligence and full expanded 216px view.
