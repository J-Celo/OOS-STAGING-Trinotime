(() => {
const CAT = Object.freeze({
  settings: 'catSettingsV2',
  data: 'catCoverageDataV2',
  bridge: 'catTrinoTimeBridgeV2',
  device: 'catDeviceIdV2',
  sync: 'catSyncStateV2',
  shift: 'catShiftSessionV1',
  recent: 'catRecentEventsV2',
  pendingTasks: 'catPendingTaskKeysV2',
  storeNames: 'catStoreNamesV1',
  migration: 'catMigratedFromTscV132',
  diagnostics: 'catDiagnosticsV2',
  noMatchExplicitOnlyMigration: 'catNoMatchExplicitOnlyV2219',
  owner: 'catLocalOwnerV1',
  archivePrefix: 'catAgentStateV1'
});

const AUGMOTO = 'https://labeling-tools.augmoto.com';
const TRINOTIME = 'https://oostrinotime-staging-qa.trinoadmin.workers.dev';
const BUILD_CHANNEL = 'staging-qa';
const EXT_VERSION = '2.2.32';
const MAX_DAYS = 45;
const MAX_RECENT_EVENTS = 4000;
const MANAGED_IDLE_MINUTES = 5;
const MANAGED_IDLE_MS = MANAGED_IDLE_MINUTES * 60 * 1000;
const SUMMARY_PENDING_KEY = '__summary__';
const VALID_TRACKER_STATES = new Set(['active', 'idle', 'away', 'paused', 'ready', 'offline', 'unknown']);

let writeChain = Promise.resolve();
let syncInFlight = null;
let lastSyncAttemptAt = 0;
let syncWakeTimer = null;
let syncFollowUpRequested = false;
let syncBackoffUntil = 0;
let syncFailureCount = 0;
let recoveryInProgress = false;

function dateKey(ts = Date.now()) {
  return new Intl.DateTimeFormat('en-CA', {
    timeZone: 'Asia/Manila', year: 'numeric', month: '2-digit', day: '2-digit'
  }).format(new Date(ts));
}
function id(prefix = 'evt') { return `${prefix}-${Date.now()}-${Math.random().toString(36).slice(2, 9)}`; }
function num(v, max = 1e9) { v = Number(v); return Number.isFinite(v) ? Math.max(0, Math.min(max, Math.floor(v))) : 0; }
function epochMs(v) { v = Number(v); return Number.isFinite(v) ? Math.max(0, Math.min(Number.MAX_SAFE_INTEGER, Math.floor(v))) : 0; }
function trackerState(v, fallback = 'unknown') {
  const state = String(v || '').toLowerCase();
  return VALID_TRACKER_STATES.has(state) ? state : fallback;
}

function submittedManual(v) {
  const n = Number(v);
  if (!Number.isFinite(n)) return 0;
  return Math.max(-100000, Math.min(100000, Math.trunc(n)));
}
function submittedDisplay(summary) {
  const confirmed = num(summary?.submitted, 1000000);
  return Math.max(0, confirmed + submittedManual(summary?.submittedManualAdjustment));
}
function syncSummarySnapshot(summary, settings) {
  const source = summary && typeof summary === 'object' ? summary : blankSummary();
  return {
    ...source,
    submittedManualAdjustment: submittedManual(source.submittedManualAdjustment),
    submittedDisplayTotal: submittedDisplay(source),
    idleThresholdMs: MANAGED_IDLE_MS,
    dailyGoal: settings?.dailyGoal || 300,
    extensionVersion: EXT_VERSION,
    buildChannel: BUILD_CHANNEL
  };
}
function defaultSettings() {
  return { enabled: true, dailyGoal: 300, idleMinutes: MANAGED_IDLE_MINUTES, hudPosition: 'bottom-left', hudExpanded: true, syncEnabled: true };
}
function cleanSettings(raw) {
  raw = raw && typeof raw === 'object' ? raw : {};
  return {
    enabled: true,
    dailyGoal: Math.max(1, Math.min(100000, Math.round(Number(raw.dailyGoal) || 300))),
    idleMinutes: MANAGED_IDLE_MINUTES,
    hudPosition: ['bottom-left', 'bottom-right', 'top-left', 'top-right'].includes(raw.hudPosition) ? raw.hudPosition : 'bottom-left',
    hudExpanded: raw.hudExpanded !== false,
    syncEnabled: true
  };
}
function blankSummary() {
  return {
    submitted: 0, created: 0, blurred: 0, deleted: 0, noMatch: 0, productMatched: 0,
    activeMs: 0, idleMs: 0, awayMs: 0, elapsedMs: 0,
    currentJob: '', currentTask: 0, totalTasks: 0,
    pendingSubmission: false, trackerState: 'offline',
    lastActivityAt: 0, idleSinceAt: 0, awaySinceAt: 0, presenceUpdatedAt: 0,
    idleThresholdMs: MANAGED_IDLE_MS, clientSequence: 0,
    submittedManualAdjustment: 0
  };
}
function blankDate() { return { summary: blankSummary(), jobs: {}, tasks: {}, updatedAt: 0 }; }
function blankData() { return { schemaVersion: 2, dates: {} }; }
function taskKey(jobId, taskIndex) { return `${String(jobId || '')}|${num(taskIndex, 100000)}`; }
function ensureDate(data, date) {
  if (!data.dates || typeof data.dates !== 'object') data.dates = {};
  if (!data.dates[date] || typeof data.dates[date] !== 'object') data.dates[date] = blankDate();
  const d = data.dates[date];
  d.summary = { ...blankSummary(), ...(d.summary || {}), idleThresholdMs: MANAGED_IDLE_MS };
  d.jobs = d.jobs && typeof d.jobs === 'object' ? d.jobs : {};
  d.tasks = d.tasks && typeof d.tasks === 'object' ? d.tasks : {};
  return d;
}
function ensureJob(day, jobId, totalTasks = 0, ts = Date.now()) {
  jobId = String(jobId || '');
  if (!jobId) return null;
  if (!day.jobs[jobId]) {
    day.jobs[jobId] = {
      jobId, submitted: 0, created: 0, blurred: 0, deleted: 0, noMatch: 0, productMatched: 0,
      activeMs: 0, idleMs: 0, awayMs: 0, elapsedMs: 0,
      lastTask: 0, totalTasks: num(totalTasks, 100000), status: 'active', firstSeenAt: ts, lastSeenAt: ts
    };
  }
  const j = day.jobs[jobId];
  j.awayMs = num(j.awayMs);
  j.totalTasks = Math.max(num(j.totalTasks, 100000), num(totalTasks, 100000));
  j.lastSeenAt = Math.max(epochMs(j.lastSeenAt), epochMs(ts));
  return j;
}
function ensureTask(day, jobId, taskIndex, totalTasks = 0, ts = Date.now()) {
  const key = taskKey(jobId, taskIndex);
  if (!jobId || !taskIndex) return null;
  if (!day.tasks[key]) {
    day.tasks[key] = {
      jobId, taskIndex: num(taskIndex, 100000), totalTasks: num(totalTasks, 100000),
      created: 0, blurred: 0, deleted: 0, noMatch: 0, productMatched: 0,
      activeMs: 0, idleMs: 0, awayMs: 0, elapsedMs: 0,
      submitted: false, skipped: false, status: 'active',
      trackerState: 'active', lastActivityAt: ts, idleSinceAt: 0, awaySinceAt: 0, idleThresholdMs: MANAGED_IDLE_MS,
      startedAt: ts, endedAt: 0, updatedAt: ts
    };
  }
  const t = day.tasks[key];
  t.noMatchAreas = t.noMatchAreas && typeof t.noMatchAreas === 'object' && !Array.isArray(t.noMatchAreas) ? t.noMatchAreas : {};
  t.awayMs = num(t.awayMs);
  t.totalTasks = Math.max(num(t.totalTasks, 100000), num(totalTasks, 100000));
  t.idleThresholdMs = MANAGED_IDLE_MS;
  t.updatedAt = Math.max(epochMs(t.updatedAt), epochMs(ts));
  return t;
}
function storeNameFromMap(core, jobId, fallback = '') {
  const id = String(jobId||'').toUpperCase();
  const known = core.storeNames?.[id]?.storeName;
  const name = String(known || fallback || '').replace(/\s+/g, ' ').trim();
  return name.length >= 4 && name.length <= 120 ? name : '';
}
async function rememberObservedStores(stores) {
  // Only job-row observations from Augmoto are accepted. Never change task totals.
  if (!Array.isArray(stores)) return {ok:false};
  return queue(async () => {
    const core = await readCore();
    const map = { ...(core.storeNames || {}) };
    let changed = 0;
    const touched = new Set();
    for (const row of stores.slice(0, 80)) {
      if (row?.source !== 'augmoto-job-row') continue;
      const jobId=String(row.jobId||'').toUpperCase(),storeName=String(row.storeName||'').replace(/\s+/g,' ').trim();
      if (!/^JOB_[A-Z0-9_-]{4,64}$/.test(jobId) || storeName.length < 4 || storeName.length > 120 || /[<>\x00-\x1f]/.test(storeName)) continue;
      if (map[jobId]?.storeName === storeName) continue;
      // Job ID must resolve consistently. Do not silently overwrite a conflicting mapping.
      if (map[jobId]?.storeName && map[jobId].storeName !== storeName) continue;
      map[jobId] = {storeName, source:'augmoto-job-row', observedAt:Date.now()};
      touched.add(jobId); changed++;
    }
    if (!changed) return {ok:true,changed:0};
    const bounded = Object.fromEntries(Object.entries(map).sort((a,b)=>(b[1].observedAt||0)-(a[1].observedAt||0)).slice(0,500));
    const date=reportDateForCore(core),day=ensureDate(core.data,date);
    if (shiftIsActive(core)) {
      for (const jobId of touched) {
        if (day.jobs[jobId]) day.jobs[jobId].storeName = bounded[jobId].storeName;
        for (const [key,task] of Object.entries(day.tasks)) if (task.jobId===jobId) {
          task.storeName=bounded[jobId].storeName;
          pendingAdd(core.pending,date,key);
        }
      }
      day.summary.clientSequence = num(day.summary.clientSequence) + 1;
      pendingAdd(core.pending,date,SUMMARY_PENDING_KEY);
    }
    await chrome.storage.local.set({ [CAT.storeNames]: bounded });
    if (shiftIsActive(core)) {
      await chrome.storage.local.set({ [CAT.data]: core.data, [CAT.pendingTasks]: core.pending });
      scheduleSyncSoon(700);
    }
    return {ok:true,changed};
  });
}
async function readCore() {
  const r = await chrome.storage.local.get([CAT.settings, CAT.data, CAT.recent, CAT.pendingTasks, CAT.bridge, CAT.device, CAT.sync, CAT.shift, CAT.storeNames]);
  return {
    settings: cleanSettings(r[CAT.settings]),
    data: r[CAT.data] && typeof r[CAT.data] === 'object' ? r[CAT.data] : blankData(),
    recent: Array.isArray(r[CAT.recent]) ? r[CAT.recent] : [],
    pending: r[CAT.pendingTasks] && typeof r[CAT.pendingTasks] === 'object' ? r[CAT.pendingTasks] : {},
    bridge: r[CAT.bridge] && typeof r[CAT.bridge] === 'object' ? r[CAT.bridge] : null,
    device: String(r[CAT.device] || ''),
    sync: r[CAT.sync] && typeof r[CAT.sync] === 'object' ? r[CAT.sync] : {},
    shift: cleanShift(r[CAT.shift]),
    storeNames: r[CAT.storeNames] && typeof r[CAT.storeNames] === 'object' ? r[CAT.storeNames] : {}
  };
}

function cleanShift(raw) {
  const source = raw && typeof raw === 'object' ? raw : {};
  const status = ['active','completed','not_clocked_in'].includes(String(source.status||'')) ? String(source.status) : 'not_clocked_in';
  return {
    sessionId: String(source.sessionId||'').slice(0,80),
    generation: Math.max(0, Math.floor(Number(source.generation)||0)),
    status,
    locked: status !== 'active',
    reportDate: /^\d{4}-\d{2}-\d{2}$/.test(String(source.reportDate||'')) ? String(source.reportDate) : '',
    startedAt: source.startedAt ? String(source.startedAt) : null,
    startedAtMs: epochMs(source.startedAtMs),
    endedAt: source.endedAt ? String(source.endedAt) : null,
    endedAtMs: epochMs(source.endedAtMs),
    lockedAt: source.lockedAt ? String(source.lockedAt) : null,
    resetAt: source.resetAt ? String(source.resetAt) : null,
    resetBy: source.resetBy ? String(source.resetBy) : null
  };
}
function shiftIsActive(core) { return core?.shift?.status === 'active' && Boolean(core.shift.sessionId); }
function reportDateForCore(core, ts = Date.now()) { return core?.shift?.reportDate || dateKey(ts); }
function localSummaryHasActivity(summary) {
  const s=summary||{};
  return ['submitted','created','blurred','deleted','noMatch','productMatched','activeMs','idleMs','awayMs','elapsedMs'].some(k=>num(s[k])>0);
}
function applyAuthoritativeCoverageSummary(day, remote) {
  if (!remote || typeof remote !== 'object') return;
  const s=day.summary={...blankSummary(),...day.summary};
  for (const key of ['submitted','created','blurred','deleted','noMatch','productMatched','activeMs','idleMs','awayMs','elapsedMs','currentTask','totalTasks','lastActivityAt','idleSinceAt','awaySinceAt','presenceUpdatedAt','clientSequence']) {
    if (remote[key] !== undefined) s[key]=num(remote[key],Number.MAX_SAFE_INTEGER);
  }
  s.submittedManualAdjustment=Number.isFinite(Number(remote.submittedManualAdjustment))?Math.trunc(Number(remote.submittedManualAdjustment)):0;
  s.currentJob=String(remote.currentJob||'');
  s.pendingSubmission=remote.pendingSubmission===true;
  s.trackerState=trackerState(remote.trackerState,'offline');
}
function adoptShiftIntoCoverageCore(core, rawShift, authoritativeSummary = null) {
  const previous=cleanShift(core.shift), next=cleanShift(rawShift);
  const date=next.reportDate || previous.reportDate || dateKey();
  next.reportDate=date;
  const identityChanged=previous.sessionId!==next.sessionId || Number(previous.generation)!==Number(next.generation);
  if (identityChanged) {
    core.data.dates[date]=blankDate();
    core.pending[date]=[];
  }
  const day=ensureDate(core.data,date);
  if(authoritativeSummary && (identityChanged || next.status!=='active' || !localSummaryHasActivity(day.summary))) applyAuthoritativeCoverageSummary(day,authoritativeSummary);
  if(next.status!=='active'){
    day.summary.pendingSubmission=false;
    day.summary.trackerState='offline';
    day.summary.currentJob='';day.summary.currentTask=0;day.summary.totalTasks=0;
    core.pending[date]=[];
  }
  core.shift=next;
  return {shift:next,date,day,identityChanged};
}
async function persistCoverageShiftCore(core){
  await chrome.storage.local.set({[CAT.shift]:core.shift,[CAT.data]:core.data,[CAT.pendingTasks]:core.pending});
}

function localOwnerIdentity(value){ return String(value||'').trim().toLowerCase(); }
function identityArchiveKey(identity){ return `${CAT.archivePrefix}:${encodeURIComponent(localOwnerIdentity(identity)).slice(0,160)}`; }
async function archiveCoverageIdentity(owner, core){
  const identity=localOwnerIdentity(owner); if(!identity)return;
  await chrome.storage.local.set({[identityArchiveKey(identity)]:{
    schemaVersion:1,owner:identity,savedAt:Date.now(),data:core.data,recent:core.recent,
    pending:core.pending,shift:core.shift,sync:core.sync
  }});
}
async function prepareCoverageIdentity(core, nextIdentity){
  const identity=localOwnerIdentity(nextIdentity); if(!identity)throw new Error('TrinoTime did not return a valid Agent identity.');
  const r=await chrome.storage.local.get(CAT.owner), previousOwner=localOwnerIdentity(r[CAT.owner]);
  const ownerChanged=Boolean(previousOwner && previousOwner!==identity);
  if(ownerChanged){
    await archiveCoverageIdentity(previousOwner,core);
    const saved=(await chrome.storage.local.get(identityArchiveKey(identity)))[identityArchiveKey(identity)];
    if(saved&&localOwnerIdentity(saved.owner)===identity){
      core.data=saved.data&&typeof saved.data==='object'?saved.data:blankData();
      core.recent=Array.isArray(saved.recent)?saved.recent.slice(-MAX_RECENT_EVENTS):[];
      core.pending=saved.pending&&typeof saved.pending==='object'?saved.pending:{};
      core.shift=cleanShift(saved.shift);
      core.sync=saved.sync&&typeof saved.sync==='object'?saved.sync:{};
    }else{
      core.data=blankData();core.recent=[];core.pending={};core.shift=cleanShift(null);core.sync={};
    }
    core.bridge=null;
  }
  return {identity,previousOwner,ownerChanged};
}

function queue(fn) { writeChain = writeChain.then(fn, fn); return writeChain; }
function pendingAdd(pending, date, key) {
  const set = new Set(Array.isArray(pending[date]) ? pending[date] : []);
  if (key) set.add(key);
  pending[date] = [...set].slice(-5000);
}
function prune(data) {
  const keys = Object.keys(data.dates || {}).sort().reverse();
  for (const k of keys.slice(MAX_DAYS)) delete data.dates[k];
}
async function diag(state, message, extra = {}) {
  const r = await chrome.storage.local.get(CAT.diagnostics);
  const m = r[CAT.diagnostics] && typeof r[CAT.diagnostics] === 'object' ? r[CAT.diagnostics] : {};
  m.last = { state, message, timestamp: Date.now(), ...extra };
  await chrome.storage.local.set({ [CAT.diagnostics]: m });
}

function applyPresenceFields(target, source, ts) {
  const state = trackerState(source.trackerState, target.trackerState || 'unknown');
  const lastActivityAt = epochMs(source.lastActivityAt || target.lastActivityAt || ts);
  const explicitIdleSinceAt = epochMs(source.idleSinceAt);
  target.trackerState = state;
  target.lastActivityAt = Math.max(epochMs(target.lastActivityAt), lastActivityAt);
  target.idleThresholdMs = MANAGED_IDLE_MS;
  target.idleSinceAt = state === 'idle'
    ? (explicitIdleSinceAt || (target.lastActivityAt ? target.lastActivityAt + MANAGED_IDLE_MS : epochMs(ts)))
    : 0;
  target.awaySinceAt = state === 'away' ? epochMs(source.awaySinceAt || target.awaySinceAt || ts) : 0;
  target.presenceUpdatedAt = epochMs(source.presenceUpdatedAt || ts);
}

async function applyEvent(event) {
  return queue(async () => {
    const core = await readCore();
    if (!shiftIsActive(core)) return { ok:true, frozen:true, shift:core.shift };
    const eventId = String(event.eventId || '');
    if (eventId && core.recent.includes(eventId)) return { ok: true, duplicate: true };

    const ts = epochMs(event.timestamp) || Date.now();
    const date = reportDateForCore(core, ts);
    const day = ensureDate(core.data, date);
    const s = day.summary;
    const jobId = String(event.jobId || s.currentJob || '');
    const ti = num(event.taskIndex || s.currentTask, 100000);
    const tt = num(event.totalTasks || s.totalTasks, 100000);

    if (jobId) { s.currentJob = jobId; s.currentTask = ti; s.totalTasks = tt || s.totalTasks; }
    applyPresenceFields(s, { ...event, lastActivityAt: event.lastActivityAt || ts }, ts);

    const job = jobId ? ensureJob(day, jobId, tt, ts) : null;
    const task = jobId && ti ? ensureTask(day, jobId, ti, tt, ts) : null;
    if (task) applyPresenceFields(task, event, ts);

    let deltaKey = '';
    switch (String(event.type || '')) {
      case 'task-start':
        if (task) {
          task.status = 'active'; task.updatedAt = ts;
          job.lastTask = Math.max(num(job.lastTask), ti); job.status = 'active';
          pendingAdd(core.pending, date, taskKey(jobId, ti));
        }
        break;
      case 'created': deltaKey = 'created'; break;
      case 'blurred': deltaKey = 'blurred'; break;
      case 'product-matched': deltaKey = 'productMatched'; break;
      case 'created-remove':
        // Q/Create is NET surviving Agent-created HUMAN boxes for this task.
        // Never subtract from a previous task/job and never go below zero.
        if (task && num(task.created) > 0) {
          task.created = num(task.created) - 1;
          if (job && num(job.created) > 0) job.created = num(job.created) - 1;
          if (num(s.created) > 0) s.created = num(s.created) - 1;
          task.updatedAt = ts;
          pendingAdd(core.pending, date, taskKey(jobId, ti));
        }
        break;
      case 'blurred-remove':
        // W/Person follows the same NET surviving-annotation rule.
        if (task && num(task.blurred) > 0) {
          task.blurred = num(task.blurred) - 1;
          if (job && num(job.blurred) > 0) job.blurred = num(job.blurred) - 1;
          if (num(s.blurred) > 0) s.blurred = num(s.blurred) - 1;
          task.updatedAt = ts;
          pendingAdd(core.pending, date, taskKey(jobId, ti));
        }
        break;
      case 'product-match-remove':
        // Product Match is NET surviving Agent-confirmed matches on this task.
        // Retract only this task's credited match and clamp at zero.
        if (task && num(task.productMatched) > 0) {
          task.productMatched = num(task.productMatched) - 1;
          if (job && num(job.productMatched) > 0) job.productMatched = num(job.productMatched) - 1;
          if (num(s.productMatched) > 0) s.productMatched = num(s.productMatched) - 1;
          task.updatedAt = ts;
          pendingAdd(core.pending, date, taskKey(jobId, ti));
        }
        break;
      case 'deleted': deltaKey = 'deleted'; break;
      case 'no-match-add': deltaKey = 'noMatch'; break;
      case 'no-match-remove':
        if (task && task.noMatch > 0) {
          task.noMatch--; if (job && job.noMatch > 0) job.noMatch--; if (s.noMatch > 0) s.noMatch--;
          pendingAdd(core.pending, date, taskKey(jobId, ti));
        }
        break;
      case 'no-match-set': {
        const area = String(event.area ?? '').trim().slice(0, 64);
        if (task && area) {
          task.noMatchAreas = task.noMatchAreas && typeof task.noMatchAreas === 'object' && !Array.isArray(task.noMatchAreas) ? task.noMatchAreas : {};
          // Explicit No-Match is idempotent per Job/Task/Area. Do not treat
          // Augmoto's confirmation check state as a toggle signal.
          if (task.noMatchAreas[area] !== true) {
            task.noMatchAreas[area] = true;
            task.noMatch = num(task.noMatch) + 1;
            if (job) job.noMatch = num(job.noMatch) + 1;
            s.noMatch = num(s.noMatch) + 1;
            task.updatedAt = ts;
            pendingAdd(core.pending, date, taskKey(jobId, ti));
          }
        }
        break;
      }
      case 'no-match-clear': {
        const area = String(event.area ?? '').trim().slice(0, 64);
        if (task && area) {
          task.noMatchAreas = task.noMatchAreas && typeof task.noMatchAreas === 'object' && !Array.isArray(task.noMatchAreas) ? task.noMatchAreas : {};
          if (task.noMatchAreas[area] === true) {
            delete task.noMatchAreas[area];
            if (task.noMatch > 0) task.noMatch--;
            if (job && job.noMatch > 0) job.noMatch--;
            if (s.noMatch > 0) s.noMatch--;
            task.updatedAt = ts;
            pendingAdd(core.pending, date, taskKey(jobId, ti));
          }
        }
        break;
      }
      case 'no-match-toggle': {
        // Backward-compatibility for an already queued v2.2.18 event: treat it
        // as an explicit mark, never as a blind toggle.
        const area = String(event.area ?? '').trim().slice(0, 64);
        if (task && area) {
          task.noMatchAreas = task.noMatchAreas && typeof task.noMatchAreas === 'object' && !Array.isArray(task.noMatchAreas) ? task.noMatchAreas : {};
          if (task.noMatchAreas[area] !== true) {
            task.noMatchAreas[area] = true;
            task.noMatch = num(task.noMatch) + 1;
            if (job) job.noMatch = num(job.noMatch) + 1;
            s.noMatch = num(s.noMatch) + 1;
            task.updatedAt = ts;
            pendingAdd(core.pending, date, taskKey(jobId, ti));
          }
        }
        break;
      }
      case 'submit-pending':
        s.pendingSubmission = true;
        if (task) { task.status = 'active'; task.updatedAt = ts; pendingAdd(core.pending, date, taskKey(jobId, ti)); }
        break;
      case 'submit-cancelled':
        s.pendingSubmission = false;
        if (task) { task.updatedAt = ts; pendingAdd(core.pending, date, taskKey(jobId, ti)); }
        break;
      case 'submit-confirmed':
        if (task && !task.submitted) {
          if(num(task.efficiencyMs)>0){s.efficiencyTaskCount=num(s.efficiencyTaskCount)+1;s.efficiencyActiveMs=num(s.efficiencyActiveMs)+num(task.efficiencyMs);}
          task.submitted = true; task.status = 'submitted'; task.endedAt = ts; task.updatedAt = ts;
          s.submitted++; if (job) job.submitted++;
        }
        s.pendingSubmission = false;
        pendingAdd(core.pending, date, taskKey(jobId, ti));
        break;
      case 'skip-confirmed':
        if (task && !task.submitted) { task.skipped = true; task.status = 'skipped'; task.endedAt = ts; task.updatedAt = ts; }
        s.pendingSubmission = false;
        pendingAdd(core.pending, date, taskKey(jobId, ti));
        break;
      case 'task-exit':
        if (task && task.status === 'active') { task.status = 'exited'; task.endedAt = ts; task.updatedAt = ts; pendingAdd(core.pending, date, taskKey(jobId, ti)); }
        if (job) job.status = 'exited';
        s.pendingSubmission = false; s.currentJob = ''; s.currentTask = 0; s.totalTasks = 0;
        // Returning to the Coverage jobs/queue page is immediate IDLE while
        // focused, or AWAY if the Augmoto tab is hidden/unfocused.
        applyPresenceFields(s, event, ts);
        break;
      case 'status':
        break;
    }

    if (deltaKey && task) {
      task[deltaKey] = num(task[deltaKey]) + 1;
      job[deltaKey] = num(job?.[deltaKey]) + 1;
      s[deltaKey] = num(s[deltaKey]) + 1;
      task.updatedAt = ts;
      pendingAdd(core.pending, date, taskKey(jobId, ti));
    }
    if (job) { job.lastTask = Math.max(num(job.lastTask), ti); job.lastSeenAt = ts; }

    pendingAdd(core.pending, date, SUMMARY_PENDING_KEY);
    day.updatedAt = ts;
    s.clientSequence = num(s.clientSequence) + 1;
    prune(core.data);
    if (eventId) core.recent.push(eventId);
    core.recent = core.recent.slice(-MAX_RECENT_EVENTS);

    await chrome.storage.local.set({ [CAT.data]: core.data, [CAT.recent]: core.recent, [CAT.pendingTasks]: core.pending });
    if (event.type === 'submit-confirmed') await appendLegacySubmission(date, event, ts);

    const fastTypes = new Set(['task-start', 'created', 'blurred', 'product-matched', 'created-remove', 'blurred-remove', 'product-match-remove', 'deleted', 'no-match-add', 'no-match-remove', 'no-match-set', 'no-match-clear', 'no-match-toggle', 'submit-pending', 'submit-cancelled', 'submit-confirmed', 'skip-confirmed', 'task-exit']);
    scheduleSyncSoon(fastTypes.has(String(event.type || '')) ? 250 : 1200);
    return { ok: true };
  });
}

async function reconcileNoMatchState(payload) {
  return queue(async () => {
    payload = payload && typeof payload === 'object' ? payload : {};
    const jobId = String(payload.jobId || '');
    const ti = num(payload.taskIndex, 100000);
    if (!jobId || !ti) return { ok: false, error: 'No active Coverage task.' };
    const ts = epochMs(payload.timestamp) || Date.now();
    const observed = [...new Set((Array.isArray(payload.observedAreas) ? payload.observedAreas : []).map(v => String(v).trim().slice(0,64)).filter(Boolean))];
    const marked = new Set((Array.isArray(payload.markedAreas) ? payload.markedAreas : []).map(v => String(v).trim().slice(0,64)).filter(Boolean));
    if (!observed.length) return { ok: true, changed: false };

    const core = await readCore();
    if (!shiftIsActive(core)) return { ok:true, frozen:true, shift:core.shift };
    const operationalDate=reportDateForCore(core,ts);
    const day = ensureDate(core.data, operationalDate);
    const date=operationalDate;
    const s = day.summary;
    const job = ensureJob(day, jobId, num(payload.totalTasks, 100000), ts);
    const task = ensureTask(day, jobId, ti, num(payload.totalTasks, 100000), ts);
    const map = task.noMatchAreas && typeof task.noMatchAreas === 'object' && !Array.isArray(task.noMatchAreas) ? task.noMatchAreas : {};
    let changed = false;
    for (const area of observed) {
      const want = marked.has(area);
      const had = map[area] === true;
      if (want === had) continue;
      changed = true;
      if (want) map[area] = true;
      else delete map[area];
    }
    if (!changed) return { ok: true, changed: false, noMatch: num(task.noMatch) };

    task.noMatchAreas = map;
    task.noMatch = Object.values(map).filter(Boolean).length;
    task.updatedAt = ts;
    // Recompute aggregate No-Match counts from task state so reconciliation can
    // repair a previously missed click instead of compounding stale deltas.
    job.noMatch = Object.values(day.tasks).filter(t => t && String(t.jobId || '') === jobId).reduce((n,t) => n + num(t.noMatch), 0);
    s.noMatch = Object.values(day.tasks).reduce((n,t) => n + num(t?.noMatch), 0);
    s.currentJob = jobId; s.currentTask = ti; s.totalTasks = Math.max(num(s.totalTasks,100000), num(payload.totalTasks,100000));
    s.clientSequence = num(s.clientSequence) + 1;
    day.updatedAt = ts; job.lastSeenAt = ts; job.lastTask = Math.max(num(job.lastTask), ti);
    pendingAdd(core.pending, date, taskKey(jobId, ti));
    pendingAdd(core.pending, date, SUMMARY_PENDING_KEY);
    await chrome.storage.local.set({ [CAT.data]: core.data, [CAT.pendingTasks]: core.pending });
    scheduleSyncSoon(250);
    return { ok: true, changed: true, noMatch: task.noMatch, summaryNoMatch: s.noMatch };
  });
}


async function migrateNoMatchToExplicitOnly() {
  try {
    const r = await chrome.storage.local.get([CAT.noMatchExplicitOnlyMigration, CAT.data, CAT.pendingTasks]);
    if (r[CAT.noMatchExplicitOnlyMigration]) return;
    const data = r[CAT.data] && typeof r[CAT.data] === 'object' ? r[CAT.data] : blankData();
    const pending = r[CAT.pendingTasks] && typeof r[CAT.pendingTasks] === 'object' ? r[CAT.pendingTasks] : {};
    let changed = false;
    for (const [date, rawDay] of Object.entries(data.dates || {})) {
      const day = ensureDate(data, date);
      // v2.2.13-v2.2.18 could manufacture X from AUTO confirmation rows.
      // Clear only still-open/unsubmitted task No-Match state; submitted task
      // history remains untouched.
      for (const task of Object.values(day.tasks || {})) {
        if (!task || task.submitted) continue;
        if (num(task.noMatch) > 0 || Object.keys(task.noMatchAreas || {}).length) {
          task.noMatch = 0;
          task.noMatchAreas = {};
          task.updatedAt = Date.now();
          pendingAdd(pending, date, taskKey(task.jobId, task.taskIndex));
          changed = true;
        }
      }
      for (const job of Object.values(day.jobs || {})) {
        if (!job) continue;
        job.noMatch = Object.values(day.tasks || {}).filter(t => t && String(t.jobId || '') === String(job.jobId || '')).reduce((n,t) => n + num(t.noMatch), 0);
      }
      day.summary.noMatch = Object.values(day.tasks || {}).reduce((n,t) => n + num(t?.noMatch), 0);
      if (changed) pendingAdd(pending, date, SUMMARY_PENDING_KEY);
    }
    await chrome.storage.local.set({ [CAT.data]: data, [CAT.pendingTasks]: pending, [CAT.noMatchExplicitOnlyMigration]: true });
    if (changed) scheduleSyncSoon(250);
  } catch (_) {}
}

async function leaveMode(){
 return queue(async()=>{
  const core=await readCore(); if(!shiftIsActive(core))return {ok:true,frozen:true,shift:core.shift};
  const ts=Date.now(),date=reportDateForCore(core,ts);
  const day=ensureDate(core.data,date),s=day.summary;
  const task=day.tasks[taskKey(s.currentJob,s.currentTask)];
  if(task&&!task.submitted){task.status='exited';task.updatedAt=ts;pendingAdd(core.pending,date,taskKey(s.currentJob,s.currentTask));}
  s.pendingSubmission=false;s.currentJob='';s.currentTask=0;s.totalTasks=0;
  applyPresenceFields(s,{trackerState:'paused',presenceUpdatedAt:ts},ts);
  s.clientSequence=num(s.clientSequence)+1;day.updatedAt=ts;
  pendingAdd(core.pending,date,SUMMARY_PENDING_KEY);
  await chrome.storage.local.set({[CAT.data]:core.data,[CAT.pendingTasks]:core.pending});
  scheduleSyncSoon(250);return {ok:true};
 });
}
async function applyEfficiencyTime(payload){
 return queue(async()=>{
  const core=await readCore(); if(!shiftIsActive(core))return {ok:true,frozen:true,shift:core.shift};
  const eventId=String(payload.eventId||'');
  if(!eventId||core.recent.includes(eventId))return {ok:true,duplicate:true};
  const date=reportDateForCore(core),ts=epochMs(payload.timestamp)||Date.now();
  if(!payload.jobId||!Number(payload.taskIndex))return {ok:false,error:'Invalid measured task.'};
  const day=ensureDate(core.data,date);
  const task=ensureTask(day,String(payload.jobId),num(payload.taskIndex),num(payload.totalTasks),ts);
  if(!task.submitted)task.efficiencyMs=num(task.efficiencyMs)+num(payload.activeMs,5000);
  core.recent.push(eventId);core.recent=core.recent.slice(-MAX_RECENT_EVENTS);
  day.summary.clientSequence=num(day.summary.clientSequence)+1;
  pendingAdd(core.pending,date,taskKey(payload.jobId,payload.taskIndex));pendingAdd(core.pending,date,SUMMARY_PENDING_KEY);
  await chrome.storage.local.set({[CAT.data]:core.data,[CAT.recent]:core.recent,[CAT.pendingTasks]:core.pending});
  scheduleSyncSoon(1200);return {ok:true};
 });
}

async function applyPresence(payload) {
  return queue(async () => {
    const core = await readCore(); if(!shiftIsActive(core))return {ok:true,frozen:true,shift:core.shift};
    const ts = epochMs(payload.timestamp) || Date.now(), date=reportDateForCore(core,ts);
    const day = ensureDate(core.data, date), s = day.summary;
    const jobId=String(payload.jobId||s.currentJob||''),ti=num(payload.taskIndex||s.currentTask,100000),tt=num(payload.totalTasks||s.totalTasks,100000);
    if(jobId){s.currentJob=jobId;s.currentTask=ti;s.totalTasks=tt||s.totalTasks;} applyPresenceFields(s,payload,ts);
    const job=jobId?ensureJob(day,jobId,tt,ts):null,task=jobId&&ti?ensureTask(day,jobId,ti,tt,ts):null;
    if(job)job.lastSeenAt=ts;if(task){applyPresenceFields(task,payload,ts);task.updatedAt=ts;pendingAdd(core.pending,date,taskKey(jobId,ti));}
    pendingAdd(core.pending,date,SUMMARY_PENDING_KEY);day.updatedAt=ts;s.clientSequence=num(s.clientSequence)+1;
    await chrome.storage.local.set({[CAT.data]:core.data,[CAT.pendingTasks]:core.pending});scheduleSyncSoon(350);return {ok:true};
  });
}

async function applyTime(payload) {
  return queue(async () => {
    const core=await readCore();if(!shiftIsActive(core))return {ok:true,frozen:true,shift:core.shift};
    const ts=epochMs(payload.timestamp)||Date.now(),date=reportDateForCore(core,ts),day=ensureDate(core.data,date),s=day.summary;
    const jobId=String(payload.jobId||s.currentJob||''),ti=num(payload.taskIndex||s.currentTask,100000),tt=num(payload.totalTasks||s.totalTasks,100000);
    const active=num(payload.activeMs,60000),idle=num(payload.idleMs,60000),away=num(payload.awayMs,60000),elapsed=num(payload.elapsedMs,60000);
    if(jobId){s.currentJob=jobId;s.currentTask=ti;s.totalTasks=tt||s.totalTasks;}s.activeMs+=active;s.idleMs+=idle;s.awayMs+=away;s.elapsedMs+=elapsed;applyPresenceFields(s,payload,ts);
    const j=jobId?ensureJob(day,jobId,tt,ts):null,t=jobId&&ti?ensureTask(day,jobId,ti,tt,ts):null;
    if(j){j.activeMs+=active;j.idleMs+=idle;j.awayMs+=away;j.elapsedMs+=elapsed;j.lastTask=Math.max(num(j.lastTask),ti);j.lastSeenAt=ts;}
    if(t){t.activeMs+=active;t.idleMs+=idle;t.awayMs+=away;t.elapsedMs+=elapsed;applyPresenceFields(t,payload,ts);t.updatedAt=ts;pendingAdd(core.pending,date,taskKey(jobId,ti));}
    pendingAdd(core.pending,date,SUMMARY_PENDING_KEY);day.updatedAt=ts;s.clientSequence=num(s.clientSequence)+1;
    await chrome.storage.local.set({[CAT.data]:core.data,[CAT.pendingTasks]:core.pending});scheduleSyncSoon(1200);return {ok:true};
  });
}

async function appendLegacySubmission(date, event, ts) {
  try {
    const r = await chrome.storage.local.get('tscRecords');
    const rows = Array.isArray(r.tscRecords) ? r.tscRecords : [];
    rows.push({
      id: id('coverage-submit'), timestamp: ts, date, origin: AUGMOTO,
      url: event.url || '', pageTitle: event.pageTitle || '',
      confirmationMethod: 'coverage-task-transition',
      confirmationMessage: `${event.jobId || ''} ${event.taskIndex || ''}/${event.totalTasks || ''}`,
      localOnly: true, sessionId: 'coverage-v2'
    });
    await chrome.storage.local.set({ tscRecords: rows.slice(-20000) });
  } catch (_) {}
}

async function migrateLegacy() {
  const r = await chrome.storage.local.get([CAT.migration, 'tscRecords', CAT.data]);
  if (r[CAT.migration]) return;
  const rows = Array.isArray(r.tscRecords) ? r.tscRecords : [];
  const data = r[CAT.data] && typeof r[CAT.data] === 'object' ? r[CAT.data] : blankData();
  const grouped = {};
  for (const row of rows) {
    if (row?.origin !== AUGMOTO) continue;
    const d = String(row.date || dateKey(row.timestamp));
    grouped[d] = (grouped[d] || 0) + 1;
  }
  for (const [d, count] of Object.entries(grouped)) {
    const day = ensureDate(data, d);
    day.summary.submitted = Math.max(num(day.summary.submitted), count);
    day.summary.clientSequence = num(day.summary.clientSequence) + 1;
  }
  prune(data);
  await chrome.storage.local.set({ [CAT.data]: data, [CAT.migration]: true });
}

async function ensureDevice() {
  const r = await chrome.storage.local.get(CAT.device);
  let device = String(r[CAT.device] || '');
  if (!device) { device = crypto.randomUUID(); await chrome.storage.local.set({ [CAT.device]: device }); }
  return device;
}

async function pairTrinoTime(preferredTabId = 0) {
  const device=await ensureDevice(), fallbackDate=dateKey();
  const tabs=await chrome.tabs.query({});
  const candidates=tabs.filter(tab=>{try{return Boolean(tab?.id)&&new URL(String(tab.url||'')).origin===TRINOTIME;}catch(_){return false;}});
  const tab=candidates.find(t=>Number(t.id)===Number(preferredTabId))||candidates.find(t=>t.active)||candidates[0];
  if(!tab?.id)throw new Error('Open TrinoTime STAGING QA in a tab and sign in as the QA Agent first.');
  const result=await chrome.scripting.executeScript({target:{tabId:tab.id},world:'MAIN',func:async(deviceId,expectedOrigin,defaultDate)=>{
    const wait=ms=>new Promise(r=>setTimeout(r,ms));if(location.origin!==expectedOrigin)throw new Error('The selected tab is not the TrinoTime STAGING QA site.');
    const authHeaders=async()=>{const headers={Accept:'application/json','Content-Type':'application/json'};const securityToken=String(window.TrinoTimeMessagingSessionContext?.getSecuritySessionToken?.()||'');if(securityToken)headers['X-TT-Security-Session']=securityToken;else{try{const user=window.firebase?.auth?.().currentUser;if(user&&!user.isAnonymous&&typeof user.getIdToken==='function')headers.Authorization=`Bearer ${await user.getIdToken(false)}`;}catch(_){}}return headers;};
    let pair=null;for(let i=0;i<16;i++){if(window.TrinoTimeCoverageBridge?.issueToken){pair=await window.TrinoTimeCoverageBridge.issueToken({deviceId,deviceName:'Coverage Activity Tracker · STAGING QA · Chrome'});break;}await wait(250);}const headers=await authHeaders();
    if(!pair){if(!headers['X-TT-Security-Session']&&!headers.Authorization)throw new Error('The TrinoTime STAGING QA secure session is not ready yet. Refresh the staging tab, wait for the QA Agent profile to load, then try Connect again.');const response=await fetch('/api/workforce/coverage/bridge-token',{method:'POST',headers,credentials:'same-origin',cache:'no-store',body:JSON.stringify({deviceId,deviceName:'Coverage Activity Tracker · STAGING QA · Chrome'})});pair=await response.json().catch(()=>({}));if(!response.ok)throw new Error(pair?.message||`Coverage pairing returned ${response.status}.`);}
    const reportDate=pair?.shift?.reportDate||defaultDate;let snapshot=null;try{if(headers['X-TT-Security-Session']||headers.Authorization){const response=await fetch(`/api/workforce/coverage/agent?date=${encodeURIComponent(reportDate)}`,{method:'GET',headers,credentials:'same-origin',cache:'no-store'});const data=await response.json().catch(()=>({}));if(response.ok&&data?.ok)snapshot=data;}}catch(_){}
    return {pair,snapshot};
  },args:[device,TRINOTIME,fallbackDate]});
  const bundle=result?.[0]?.result||{},value=bundle.pair||bundle;if(!value?.ok||!value.bridgeToken)throw new Error(value?.message||'TrinoTime STAGING QA did not issue a Coverage bridge token.');
  const bridge={baseUrl:TRINOTIME,token:String(value.bridgeToken),expiresAt:String(value.expiresAt||''),expiresAtMs:epochMs(value.expiresAtMs),actor:value.actor||null,deviceId:device,connectedAt:Date.now(),lastSyncAt:0};
  const core=await readCore(),identityState=await prepareCoverageIdentity(core,value.actor?.name),snapshot=bundle.snapshot&&typeof bundle.snapshot==='object'?bundle.snapshot:null;
  let shift=value.shift||{status:'not_clocked_in',reportDate:fallbackDate}, authoritativeSummary=snapshot?.summary||null;
  if(!authoritativeSummary){
    try{const response=await fetch(`${bridge.baseUrl}/api/workforce/coverage/shift-state`,{method:'GET',headers:{Accept:'application/json','X-TT-Coverage-Bridge':bridge.token},cache:'no-store'}),body=await response.json().catch(()=>({}));if(response.ok&&body?.ok){shift=body.shift||shift;authoritativeSummary=body.summary||null;}}catch(_){}
  }
  const adopted=adoptShiftIntoCoverageCore(core,shift,authoritativeSummary),day=adopted.day;
  const localHasActivity=localSummaryHasActivity(day.summary)||Object.keys(day.tasks||{}).length>0||Object.keys(day.jobs||{}).length>0;
  if(!localHasActivity&&snapshot?.summary){applyAuthoritativeCoverageSummary(day,snapshot.summary);day.jobs={};for(const job of Array.isArray(snapshot.jobs)?snapshot.jobs:[])if(job?.jobId)day.jobs[String(job.jobId)]={...job};day.tasks={};for(const task of Array.isArray(snapshot.tasks)?snapshot.tasks:[])if(task?.jobId&&task?.taskIndex)day.tasks[taskKey(task.jobId,task.taskIndex)]={...task,noMatchAreas:task.noMatchAreas||{}};}
  core.bridge=bridge;if(adopted.shift.status==='active')core.pending[adopted.date]=[...Object.keys(day.tasks),SUMMARY_PENDING_KEY];else core.pending[adopted.date]=[];
  await chrome.storage.local.set({[CAT.data]:core.data,[CAT.bridge]:bridge,[CAT.pendingTasks]:core.pending,[CAT.shift]:adopted.shift,[CAT.recent]:core.recent,[CAT.sync]:core.sync,[CAT.owner]:identityState.identity});
  await diag(identityState.ownerChanged?'identity-handoff':'connected',`Connected to TrinoTime STAGING QA as ${value.actor?.name||'Agent'}.`,{actor:value.actor||null,previousOwner:identityState.previousOwner||null,shift:adopted.shift});
  if(adopted.shift.status==='active')await syncDirty(true);
  return {ok:true,bridge,shift:adopted.shift,restoredFromServer:Boolean(authoritativeSummary),identityChanged:identityState.ownerChanged};
}

// Explicit two-factor shift recovery: authenticated TrinoTime tab + signed bridge.
// Never perform this implicitly at startup or on ordinary Connect.
async function trackerRecoveryCall(tabId,stage,core,recoveryId=''){
  const bridge=core.bridge,shift=core.shift;
  const result=await chrome.scripting.executeScript({target:{tabId},world:'MAIN',func:async(workflow,stage,deviceId,bridgeToken,sessionId,generation,recoveryId,expectedOrigin)=>{
    if(location.origin!==expectedOrigin)throw new Error('Recovery must be initiated from the TrinoTime STAGING QA tab.');
    const headers={Accept:'application/json','Content-Type':'application/json'};
    const security=String(window.TrinoTimeMessagingSessionContext?.getSecuritySessionToken?.()||'');
    if(security)headers['X-TT-Security-Session']=security;
    else{try{const user=window.firebase?.auth?.().currentUser;if(user&&!user.isAnonymous&&typeof user.getIdToken==='function')headers.Authorization=`Bearer ${await user.getIdToken(false)}`;}catch(_){}}
    if(!headers['X-TT-Security-Session']&&!headers.Authorization)throw new Error('Sign in to your TrinoTime staging Agent account and retry recovery.');
    headers[workflow==='coverage'?'X-TT-Coverage-Bridge':'X-TT-Confirmation-Bridge']=bridgeToken;
    const endpoint=stage==='ack'?'recover-ack':'recover-current-shift';
    const payload=stage==='ack'?{deviceId,recoveryId}:{deviceId,shiftSessionId:sessionId,shiftGeneration:generation,confirmation:'RECOVER_MY_ACTIVE_SHIFT'};
    const response=await fetch(`/api/workforce/${workflow}/${endpoint}`,{method:'POST',headers,credentials:'same-origin',cache:'no-store',body:JSON.stringify(payload)});
    const data=await response.json().catch(()=>({}));
    if(!response.ok)throw new Error(data?.message||`Shift recovery returned ${response.status}.`);
    return data;
  },args:['coverage',stage,bridge.deviceId,bridge.token,shift.sessionId,shift.generation,recoveryId,TRINOTIME]});
  const response=result?.[0]?.result;
  if(!response?.ok)throw new Error(response?.message||'The recovery response could not be verified.');
  return response;
}
function trackerRecoveryHasLocalWork(day){
  const s=day?.summary||{};
  const counters=['submitted','created','blurred','deleted','noMatch','productMatched'];
  return counters.some(key=>num(s[key])>0)||Object.keys(day?.jobs||{}).length>0||Object.keys(day?.tasks||{}).length>0;
}
async function recoverCurrentShift(){
  if(recoveryInProgress)return {ok:false,error:'Recovery is already running.'};
  recoveryInProgress=true;
  if(syncWakeTimer){clearTimeout(syncWakeTimer);syncWakeTimer=null;}
  try{
    if(syncInFlight)await syncInFlight.catch(()=>{});
    const core=await readCore();
    if(!core.bridge?.token||!shiftIsActive(core))throw new Error('Connect the Tracker and Time In before recovering this shift.');
    const checkpoint=(await chrome.storage.local.get('catRecoveryCheckpointV1'))['catRecoveryCheckpointV1'];
    if(checkpoint?.recoveryId&&checkpoint.shiftSessionId===core.shift.sessionId&&checkpoint.deviceId===core.bridge.deviceId){
      const tabs=await chrome.tabs.query({});
      const tab=tabs.find(t=>{try{return t.id&&new URL(String(t.url||'')).origin===TRINOTIME;}catch(_){return false;}});
      if(!tab?.id)throw new Error('Open TrinoTime STAGING QA and sign in to complete the pending recovery acknowledgment.');
      await trackerRecoveryCall(tab.id,'ack',core,checkpoint.recoveryId);
      await chrome.storage.local.remove('catRecoveryCheckpointV1');
      syncBackoffUntil=0;syncFailureCount=0;syncFollowUpRequested=false;
      await chrome.storage.local.set({[CAT.sync]:{state:'ok',lastSyncAt:Date.now(),lastMessage:'Shift safely recovered',lastError:''}});
      return {ok:true,resumedPendingRecovery:true};
    }
    // A previous click can finish one workflow while the other still needs recovery.
    // Verify the server still recognizes this device before treating that workflow as done.
    if(core.sync?.state==='ok'&&core.sync?.lastMessage==='Shift safely recovered'){
      const response=await fetch(`${core.bridge.baseUrl}/api/workforce/coverage/shift-state`,{headers:{Accept:'application/json','X-TT-Coverage-Bridge':core.bridge.token},cache:'no-store'});
      const body=await response.json().catch(()=>({}));
      if(response.ok&&body.ok&&body.shift?.sessionId===core.shift.sessionId&&Number(body.shift?.generation||0)===Number(core.shift.generation||0)&&body.summary?.deviceId===core.bridge.deviceId&&!body.summary?.recoveryPending){
        return {ok:true,alreadyRecovered:true,shift:body.shift};
      }
    }
    const date=reportDateForCore(core),day=ensureDate(core.data,date);
    if(trackerRecoveryHasLocalWork(day))throw new Error('This new Tracker already has task/job counts. Recovery cannot replace unsynced local work. Keep this installation and ask the staging administrator to reconcile it safely.');
    const tabs=await chrome.tabs.query({});
    const tab=tabs.find(t=>{try{return t.id&&new URL(String(t.url||'')).origin===TRINOTIME;}catch(_){return false;}});
    if(!tab?.id)throw new Error('Open TrinoTime STAGING QA, sign in as this Agent, then click Recover This Shift again.');
    const result=await trackerRecoveryCall(tab.id,'recover',core);
    const remoteShift=cleanShift(result.shift);
    if(remoteShift.sessionId!==core.shift.sessionId||remoteShift.generation!==core.shift.generation||remoteShift.status!=='active')throw new Error('The shift changed during recovery. No local work was cleared.');
    const jobs=Array.isArray(result.jobs)?result.jobs:[],tasks=Array.isArray(result.tasks)?result.tasks:[];
    // Durable backup before rehydration. Restore only after server explicitly confirms ownership.
    const prepared=await queue(async()=>{
      const latest=await readCore(),candidate=ensureDate(latest.data,date);
      if(latest.bridge?.token!==core.bridge.token||latest.shift.sessionId!==core.shift.sessionId||trackerRecoveryHasLocalWork(candidate))throw new Error('Local Tracker state changed during recovery. Server recovery remains pending; stop counting and retry.');
      await chrome.storage.local.set({[`catPreRecoveryBackupV1`]:{savedAt:Date.now(),shift:latest.shift,data:latest.data,pending:latest.pending}});
      latest.data.dates[date]=blankDate();
      const restored=ensureDate(latest.data,date);
      if(result.summary)applyAuthoritativeCoverageSummary(restored,result.summary);
      if(result.summary){
        // Restore metric baselines that the regular shift-state lightweight adoption
        // intentionally does not hydrate. This prevents post-handoff metric resets.
        for(const key of ['efficiencyTaskCount','efficiencyActiveMs','productMatched','created','blurred','deleted','noMatch','awayTimingAvailable']){
          if(result.summary[key]!==undefined)restored.summary[key]=key==='awayTimingAvailable'?result.summary[key]===true:num(result.summary[key]);
        }
        if(result.summary.currentStoreName)restored.summary.currentStoreName=String(result.summary.currentStoreName);
      }
      for(const job of jobs){if(job?.jobId)restored.jobs[String(job.jobId)]={...job};}
      for(const task of tasks){if(task?.jobId&&task?.taskIndex)restored.tasks[taskKey(task.jobId,task.taskIndex)]={...task,noMatchAreas:task.noMatchAreas||{}};}
      restored.summary.pendingSubmission=false;
      restored.summary.trackerState='ready';
      restored.summary.currentJob='';restored.summary.currentTask=0;restored.summary.totalTasks=0;
      // Pending server-job rewrites are forbidden: these rows already exist server-side.
      latest.pending[date]=[];
      latest.shift=remoteShift;
      await chrome.storage.local.set({[CAT.data]:latest.data,[CAT.pendingTasks]:latest.pending,[CAT.shift]:latest.shift,[CAT.sync]:{state:'recovering',lastMessage:'Restored, awaiting server handoff confirmation',lastError:''}});
      if(result.recoveryId)await chrome.storage.local.set({'catRecoveryCheckpointV1':{recoveryId:result.recoveryId,shiftSessionId:remoteShift.sessionId,deviceId:core.bridge.deviceId,at:Date.now()}});
      return {restoredJobs:jobs.length,restoredTasks:tasks.length};
    });
    if(result.recoveryId){await trackerRecoveryCall(tab.id,'ack',core,result.recoveryId);}
    await chrome.storage.local.remove('catRecoveryCheckpointV1');
    syncBackoffUntil=0;syncFailureCount=0;syncFollowUpRequested=false;
    await chrome.storage.local.set({[CAT.sync]:{state:'ok',lastSyncAt:Date.now(),lastMessage:'Shift safely recovered',lastError:''}});
    await diag('shift-recovery','Verified same-Agent, same-shift Tracker handoff without resetting server totals.',prepared);
    return {ok:true,shift:remoteShift,...prepared,alreadyOwned:Boolean(result.alreadyOwned)};
  }catch(error){
    await diag('shift-recovery-blocked',String(error?.message||error));
    return {ok:false,error:String(error?.message||error)};
  }finally{recoveryInProgress=false;}
}
async function refreshShiftState(){
  const core=await readCore(),bridge=core.bridge;if(!bridge?.token)return {ok:false,skipped:true,shift:core.shift};
  const response=await fetch(`${bridge.baseUrl}/api/workforce/coverage/shift-state`,{method:'GET',headers:{Accept:'application/json','X-TT-Coverage-Bridge':bridge.token},cache:'no-store'});
  const body=await response.json().catch(()=>({}));if(!response.ok){const e=new Error(body?.message||`Shift state returned ${response.status}.`);e.status=response.status;throw e;}
  return queue(async()=>{const latest=await readCore();const adopted=adoptShiftIntoCoverageCore(latest,body.shift,body.summary||null);await persistCoverageShiftCore(latest);return {ok:true,shift:adopted.shift,summary:adopted.day.summary,sessionChanged:adopted.identityChanged};});
}
async function resetCurrentShift(){
  const core=await readCore(),bridge=core.bridge;if(!bridge?.token)throw new Error('Connect the Tracker to TrinoTime first.');
  if(!shiftIsActive(core))throw new Error('Reset Current Shift is available only while you are Timed In.');
  const response=await fetch(`${bridge.baseUrl}/api/workforce/coverage/reset-current-shift`,{method:'POST',headers:{Accept:'application/json','Content-Type':'application/json','X-TT-Coverage-Bridge':bridge.token},body:JSON.stringify({deviceId:bridge.deviceId,reason:'agent_manual_tracker_reset'}),cache:'no-store'});
  const body=await response.json().catch(()=>({}));if(!response.ok)throw new Error(body?.message||`Reset returned ${response.status}.`);
  return queue(async()=>{const latest=await readCore();const adopted=adoptShiftIntoCoverageCore(latest,body.shift,null);latest.data.dates[adopted.date]=blankDate();latest.pending[adopted.date]=[];latest.shift=cleanShift(body.shift);await persistCoverageShiftCore(latest);await diag('manual-reset','Current shift Coverage + Confirmation totals were reset from TrinoTime.',{reset:body.reset||null,shift:latest.shift});return {ok:true,shift:latest.shift,reset:body.reset||null};});
}

async function handleTrinoTimeSessionEnding() {
  const syncResult=await syncDirty(true).catch(error=>({ok:false,error:String(error?.message||error)}));
  return queue(async()=>{
    const core=await readCore(), owner=localOwnerIdentity((await chrome.storage.local.get(CAT.owner))[CAT.owner]);
    const date=reportDateForCore(core),day=ensureDate(core.data,date);
    day.summary.pendingSubmission=false;day.summary.trackerState='offline';day.summary.currentJob='';day.summary.currentTask=0;day.summary.totalTasks=0;
    if(core.shift.status==='active')core.shift={...core.shift,status:'not_clocked_in',locked:true};
    core.bridge=null;
    await archiveCoverageIdentity(owner,core);
    await chrome.storage.local.set({[CAT.data]:core.data,[CAT.shift]:core.shift,[CAT.pendingTasks]:core.pending,[CAT.sync]:{...(core.sync||{}),state:'idle',lastMessage:'TrinoTime signed out · connection cleared',lastError:''}});
    await chrome.storage.local.remove(CAT.bridge);
    await diag('session-ended','TrinoTime Agent signed out. Coverage tracking was frozen and the local bridge was cleared.',{owner:owner||null,syncBeforeDisconnect:Boolean(syncResult?.ok)});
    return {ok:true,frozen:true,owner:owner||null,syncBeforeDisconnect:Boolean(syncResult?.ok)};
  });
}

async function disconnectLocal() {
  await chrome.storage.local.remove(CAT.bridge);
  await diag('disconnected', 'TrinoTime bridge removed from this browser.');
  return { ok: true };
}

function scheduleSyncSoon(delayMs = 900) {
  const delay = Math.max(200, Math.min(60000, Number(delayMs) || 700));
  if (syncInFlight) { syncFollowUpRequested = true; return; }
  if (syncWakeTimer) clearTimeout(syncWakeTimer);
  const minGap = Math.max(0, 500 - (Date.now() - lastSyncAttemptAt));
  const backoff = Math.max(0, syncBackoffUntil - Date.now());
  syncWakeTimer = setTimeout(() => { syncWakeTimer = null; syncDirty(false).catch(() => {}); }, Math.max(delay, minGap, backoff));
}

async function syncDirty(force = false) {
  if(recoveryInProgress)return {ok:false,recovering:true};
  if(syncInFlight){syncFollowUpRequested=true;return syncInFlight;}if(syncWakeTimer){clearTimeout(syncWakeTimer);syncWakeTimer=null;}
  syncInFlight=(async()=>{
    lastSyncAttemptAt=Date.now();if((await chrome.storage.local.get('catRecoveryCheckpointV1'))['catRecoveryCheckpointV1'])return {ok:false,recovering:true};let core=await readCore(),bridge=core.bridge;if(!bridge?.token||core.settings.syncEnabled===false)return {ok:false,skipped:true};
    const parsedExpiryMs=Date.parse(String(bridge.expiresAt||'')),effectiveExpiryMs=epochMs(bridge.expiresAtMs)>=1000000000000?epochMs(bridge.expiresAtMs):(Number.isFinite(parsedExpiryMs)?epochMs(parsedExpiryMs):epochMs(bridge.expiresAtMs));
    if(effectiveExpiryMs&&effectiveExpiryMs<Date.now()+5000){const message='TrinoTime Coverage bridge expired. Reconnect from the extension popup.';await diag('expired',message);await chrome.storage.local.set({[CAT.sync]:{state:'error',lastAttemptAt:Date.now(),lastMessage:'Bridge expired',lastError:message}});return {ok:false,expired:true};}
    if(!shiftIsActive(core)){const refreshed=await refreshShiftState().catch(()=>null);core=await readCore();if(!shiftIsActive(core))return {ok:true,locked:true,shift:core.shift,refreshed:Boolean(refreshed)};}
    const date=reportDateForCore(core),day=ensureDate(core.data,date),keys=Array.isArray(core.pending[date])?core.pending[date].slice(0,150):[];
    if(!keys.length&&!force)return {ok:true,nothing:true};
    const taskKeys=keys.filter(k=>k!==SUMMARY_PENDING_KEY),taskVersions=Object.fromEntries(taskKeys.map(k=>[k,JSON.stringify(day.tasks?.[k]||null)])),tasks=taskKeys.map(k=>day.tasks[k]).filter(Boolean).map(v=>({...v,storeName:storeNameFromMap(core,v.jobId,v.storeName)})),jobs=Object.values(day.jobs||{}).slice(0,80).map(j=>({...j,storeName:storeNameFromMap(core,j.jobId,j.storeName)})),summary={...syncSummarySnapshot(day.summary,core.settings),currentStoreName:storeNameFromMap(core,day.summary.currentJob,day.summary.currentStoreName)},summaryVersion=JSON.stringify(syncSummarySnapshot(day.summary,core.settings));
    const response=await fetch(`${bridge.baseUrl}/api/workforce/coverage/sync`,{method:'POST',headers:{Accept:'application/json','Content-Type':'application/json','X-TT-Coverage-Bridge':bridge.token},body:JSON.stringify({schemaVersion:1,date,deviceId:bridge.deviceId,clientUpdatedAt:new Date().toISOString(),clientSequence:num(day.summary.clientSequence),shiftSessionId:core.shift.sessionId,shiftGeneration:core.shift.generation,summary,jobs,tasks}),cache:'no-store'});
    const body=await response.json().catch(()=>({}));if(!response.ok){if([401,403].includes(response.status))await diag('auth-error',body?.message||'TrinoTime bridge needs to be reconnected.',{code:body?.error||''});const e=new Error(body?.message||`TrinoTime sync returned ${response.status}.`);e.status=response.status;e.code=body?.error||'TRINOTIME_SYNC_HTTP_ERROR';throw e;}
    if(body?.locked===true||body?.sessionChanged===true){await queue(async()=>{const latest=await readCore();adoptShiftIntoCoverageCore(latest,body.shift,body.summary||null);await persistCoverageShiftCore(latest);await chrome.storage.local.set({[CAT.sync]:{state:'ok',lastSyncAt:Date.now(),lastAttemptAt:Date.now(),lastMessage:body.locked?'Shift locked':'New shift detected',lastError:''}});});return {ok:true,locked:Boolean(body.locked),sessionChanged:Boolean(body.sessionChanged),shift:body.shift};}
    if(body?.stale===true){const accepted=Math.max(0,Math.floor(Number(body.acceptedSequence)||0)),message=`TrinoTime rejected an older Coverage sequence${accepted?` (server ${accepted})`:''}. Local pending data was preserved instead of being falsely marked synced.`;await diag('sequence-conflict',message,{acceptedSequence:accepted,localSequence:num(day.summary.clientSequence)});throw new Error(message);}
    await queue(async()=>{const latest=await readCore(),pending=latest.pending,latestDay=ensureDate(latest.data,date);if(keys.length){const remove=new Set(keys);pending[date]=(Array.isArray(pending[date])?pending[date]:[]).filter(k=>{if(!remove.has(k))return true;if(k===SUMMARY_PENDING_KEY)return JSON.stringify(syncSummarySnapshot(latestDay.summary,latest.settings))!==summaryVersion;return JSON.stringify(latestDay.tasks?.[k]||null)!==String(taskVersions[k]||'null');});}else if(!pending[date])pending[date]=[];if(body.shift)adoptShiftIntoCoverageCore(latest,body.shift,null);const syncedAt=Date.now(),newBridge={...(latest.bridge||bridge),lastSyncAt:syncedAt};await chrome.storage.local.set({[CAT.pendingTasks]:pending,[CAT.bridge]:newBridge,[CAT.shift]:latest.shift,[CAT.data]:latest.data,[CAT.sync]:{state:'ok',lastSyncAt:syncedAt,lastAttemptAt:syncedAt,lastMessage:`Live sync ${date}`,lastError:'',acceptedSequence:Math.max(0,Math.floor(Number(body?.acceptedSequence)||num(day.summary.clientSequence)))}});if(Array.isArray(pending[date])&&pending[date].length)syncFollowUpRequested=true;});
    syncBackoffUntil=0;syncFailureCount=0;await diag('sync-ok','Coverage data synced to TrinoTime.',{synced:1,shift:body.shift||core.shift});return {ok:true,synced:1,shift:body.shift||core.shift};
  })().catch(async error=>{const status=Number(error?.status)||0,authFailure=status===401||status===403;syncFailureCount=authFailure?0:Math.min(6,syncFailureCount+1);const retryDelay=authFailure?0:Math.min(60000,2500*Math.pow(2,Math.max(0,syncFailureCount-1)));syncBackoffUntil=retryDelay?Date.now()+retryDelay:0;await chrome.storage.local.set({[CAT.sync]:{state:'error',lastAttemptAt:Date.now(),lastMessage:authFailure?'Reconnect required':`Sync retry in ${Math.round(retryDelay/1000)}s`,lastError:String(error.message||error),retryAt:retryDelay?Date.now()+retryDelay:0}});if(authFailure)syncFollowUpRequested=false;else syncFollowUpRequested=true;return {ok:false,error:String(error.message||error),retryInMs:retryDelay};}).finally(()=>{syncInFlight=null;if(syncFollowUpRequested){syncFollowUpRequested=false;scheduleSyncSoon(300);}});return syncInFlight;
}


async function adjustSubmitted(delta) {
  return queue(async()=>{const step=Number(delta);if(!Number.isFinite(step)||![1,-1].includes(Math.trunc(step)))return {ok:false,error:'Invalid submitted adjustment.'};const core=await readCore();if(!shiftIsActive(core))return {ok:false,frozen:true,error:'Time In is required. Completed shift totals are locked.',shift:core.shift};const date=reportDateForCore(core),day=ensureDate(core.data,date),s=day.summary,confirmed=num(s.submitted,1000000),current=submittedManual(s.submittedManualAdjustment),next=Math.max(-confirmed,Math.min(100000,current+Math.trunc(step)));s.submittedManualAdjustment=next;s.clientSequence=num(s.clientSequence)+1;day.updatedAt=Date.now();pendingAdd(core.pending,date,SUMMARY_PENDING_KEY);await chrome.storage.local.set({[CAT.data]:core.data,[CAT.pendingTasks]:core.pending});scheduleSyncSoon(350);return {ok:true,confirmed,manual:next,total:submittedDisplay(s)};});
}

async function context() {
  const core=await readCore(),today=reportDateForCore(core),day=ensureDate(core.data,today);
  return {origin:AUGMOTO,settings:core.settings,today,summary:{...day.summary,submittedManualAdjustment:submittedManual(day.summary.submittedManualAdjustment),submittedDisplayTotal:submittedDisplay(day.summary)},jobs:day.jobs,tasks:day.tasks,bridge:core.bridge,sync:core.sync,shift:core.shift,trackingLocked:!shiftIsActive(core),managedIdlePolicy:{minutes:MANAGED_IDLE_MINUTES,milliseconds:MANAGED_IDLE_MS},diagnostics:(await chrome.storage.local.get(CAT.diagnostics))[CAT.diagnostics]||null};
}

async function updateSettings(patch) {
  const r = await chrome.storage.local.get(CAT.settings);
  const next = cleanSettings({ ...cleanSettings(r[CAT.settings]), ...(patch || {}) });
  await chrome.storage.local.set({ [CAT.settings]: next });
  return next;
}

async function clearToday() {
  return { ok: false, error: 'Managed Coverage mode does not allow Agents to clear today’s tracked activity.' };
}

chrome.runtime.onInstalled.addListener(async () => {
  await ensureDevice();
  const r = await chrome.storage.local.get(CAT.settings);
  await chrome.storage.local.set({ [CAT.settings]: cleanSettings(r[CAT.settings] || defaultSettings()) });
  await migrateLegacy();
  chrome.alarms.create('cat-sync', { periodInMinutes: 1 });
  refreshShiftState().then(()=>syncDirty(false)).catch(() => {});
  try {
    const tabs = await chrome.tabs.query({ url: `${AUGMOTO}/*` });
    await Promise.allSettled(tabs.filter(t => t.id).map(t => chrome.scripting.executeScript({ target: { tabId: t.id }, files: ['job-mode.js','task-efficiency.js','hud-appearance.js','store-intelligence.js','coverage.js','confirmation.js'] })));
  } catch (_) {}
});
chrome.runtime.onStartup.addListener(() => {
  chrome.alarms.create('cat-sync', { periodInMinutes: 1 });
  refreshShiftState().then(()=>syncDirty(false)).catch(() => {});
  migrateLegacy().catch(() => {});
  chrome.storage.local.get(CAT.settings).then(r => chrome.storage.local.set({ [CAT.settings]: cleanSettings(r[CAT.settings] || defaultSettings()) })).catch(() => {});
});
chrome.alarms.onAlarm.addListener(alarm => { if (alarm.name === 'cat-sync') refreshShiftState().then(()=>syncDirty(false)).catch(() => {}); });
chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  if (!message || !String(message.type || '').startsWith('cat-')) return;
  const run = async () => {
    switch (message.type) {
      case 'cat-context': return context();
      case 'cat-mode-leave': return leaveMode();
      case 'cat-efficiency-time': return applyEfficiencyTime(message.payload||{});
      case 'cat-store-observed': return rememberObservedStores(message.stores);
      case 'cat-event': return applyEvent(message.event || {});
      case 'cat-no-match-reconcile': return { ok: true, ignored: true, reason: 'v2.2.19 explicit No-Match actions only' };
      case 'cat-presence': return applyPresence(message.payload || {});
      case 'cat-time': return applyTime(message.payload || {});
      case 'cat-settings': return { ok: true, settings: await updateSettings(message.patch || {}) };
      case 'cat-pair-trinotime': return pairTrinoTime(Number(message.preferredTabId)||Number(sender?.tab?.id)||0);
      case 'cat-session-ending': return handleTrinoTimeSessionEnding();
      case 'cat-recover-shift': return recoverCurrentShift();
      case 'cat-sync-now': await refreshShiftState().catch(()=>{}); return syncDirty(true);
      case 'cat-refresh-shift': return refreshShiftState();
      case 'cat-reset-current-shift': return resetCurrentShift();
      case 'cat-adjust-submitted': return adjustSubmitted(message.delta);
      case 'cat-disconnect-local': return disconnectLocal();
      case 'cat-clear-today': return clearToday();
      case 'cat-diagnostic': await diag(message.state || 'info', message.message || '', message.extra || {}); return { ok: true };
      default: return { ok: false, error: 'Unknown Coverage Tracker message.' };
    }
  };
  run().then(sendResponse).catch(error => sendResponse({ ok: false, error: String(error.message || error) }));
  return true;
});

// One-time repair for phantom No-Match values created by pre-v2.2.19 rail inference.
migrateNoMatchToExplicitOnly().catch(()=>{});

})();
