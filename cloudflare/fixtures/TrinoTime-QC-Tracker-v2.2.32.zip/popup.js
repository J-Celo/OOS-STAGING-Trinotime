const $=id=>document.getElementById(id);
const CONNECT_LABEL='Connect both to TrinoTime STAGING QA';
const CONNECTED_LABEL='Connected to both · STAGING QA';

function setMode(mode){
 const card=$('modeCard'),pill=$('modePill');
 card.dataset.mode=mode||'none';
 if(mode==='coverage'){$('mode').textContent='Coverage';pill.textContent='ACTIVE';return;}
 if(mode==='confirmation'){$('mode').textContent='Confirmation';pill.textContent='ACTIVE';return;}
 if(mode==='none'){$('mode').textContent='Select a QC task in Augmoto';pill.textContent='PAUSED';return;}
 $('mode').textContent='Open Augmoto to detect the selected job';pill.textContent='READY';
}


function fmtAgo(ms){
 const n=Number(ms)||0;if(!n)return 'not synced';const sec=Math.max(0,Math.round((Date.now()-n)/1000));if(sec<5)return 'just now';if(sec<60)return sec+'s ago';return Math.round(sec/60)+'m ago';
}
function renderSyncHealth(coverage,confirmation){
 const cSync=coverage?.sync||{},fSync=confirmation?.sync||{};
 const cOk=cSync.state==='ok',fOk=fSync.state==='ok';
 const cEl=$('coverageSync'),fEl=$('confirmationSync');if(!cEl||!fEl)return;
 cEl.textContent=`Coverage · ${cOk?fmtAgo(cSync.lastSyncAt):(cSync.lastMessage||'not synced')}`;
 fEl.textContent=`Confirmation · ${fOk?fmtAgo(fSync.lastSyncAt):(fSync.lastMessage||'not synced')}`;
 cEl.dataset.state=cOk?'ok':(cSync.state||'idle');
 fEl.dataset.state=fOk?'ok':(fSync.state||'idle');
 const conflict=[cSync,fSync].some(item=>item.state==='recovering'||/another browser|recovery pending|finish shift recovery/i.test(String(item.lastError||'')));
 const recover=$('recoverShift'),help=$('recoveryHelp');if(recover){recover.hidden=!conflict;help.hidden=!conflict;}
}


function renderShift(coverage,confirmation){
 const shift=coverage?.shift||confirmation?.shift||{status:'not_clocked_in'};
 const state=String(shift.status||'not_clocked_in');
 const card=$('shiftCard'),pill=$('shiftPill'),reset=$('resetShift');if(!card)return;card.dataset.state=state;
 if(state==='active'){ $('shiftTitle').textContent='Shift tracking active'; pill.textContent='ACTIVE'; const started=shift.startedAt?new Date(shift.startedAt).toLocaleString():''; $('shiftMeta').textContent=`${shift.reportDate||'Current shift'}${started?` · Time In ${started}`:''} · OT continues until Time Out`; }
 else if(state==='completed'){ $('shiftTitle').textContent='Shift completed · totals locked';pill.textContent='LOCKED';const ended=shift.endedAt?new Date(shift.endedAt).toLocaleString():'';$('shiftMeta').textContent=`${shift.reportDate||'Completed shift'}${ended?` · Time Out ${ended}`:''} · Next Time In starts at 0`; }
 else{$('shiftTitle').textContent='Time In required';pill.textContent='WAITING';$('shiftMeta').textContent='Tracker will begin a fresh session after TrinoTime Time In.';}
 if(reset){const conflict=[coverage?.sync,confirmation?.sync].some(item=>item?.state==='recovering'||/another browser|recovery pending|finish shift recovery/i.test(String(item?.lastError||'')));reset.disabled=state!=='active'||!coverage?.bridge?.token||conflict;reset.textContent=state==='completed'?'Shift Locked':'Reset Current Shift';reset.title=conflict?'Disabled during device conflict. Use Recover This Shift instead of resetting counters.':'';}
}

function setConnectState(connected){
 const button=$('connect');
 const label=$('connectLabel');
 button.dataset.connected=connected?'true':'false';
 button.classList.toggle('isConnected',connected);
 label.textContent=connected?CONNECTED_LABEL:CONNECT_LABEL;
 button.title=connected?'Connected to both staging bridges. Click to reconnect both.':'Connect Coverage and Confirmation to TrinoTime STAGING QA.';
}

async function refreshConnectionState({announce=true}={}){
 try{
  const [coverage,confirmation]=await Promise.all([
   chrome.runtime.sendMessage({type:'cat-context'}),
   chrome.runtime.sendMessage({type:'cft-context'})
  ]);
  const coverageConnected=Boolean(coverage?.bridge?.token);
  const confirmationConnected=Boolean(confirmation?.bridge?.token);
  const coverageAgent=String(coverage?.bridge?.actor?.name||'').trim();
  const confirmationAgent=String(confirmation?.bridge?.actor?.name||'').trim();
  const identitiesMatch=!coverageConnected||!confirmationConnected||coverageAgent.toLowerCase()===confirmationAgent.toLowerCase();
  const both=coverageConnected&&confirmationConnected&&identitiesMatch;
  setConnectState(both);
  renderSyncHealth(coverage,confirmation);
  renderShift(coverage,confirmation);
  if(announce){
   if(both)$('status').textContent=`Connected as ${coverageAgent||'Agent'}. Coverage and Confirmation are identity-matched.`;
   else if(coverageConnected&&confirmationConnected&&!identitiesMatch)$('status').textContent=`Identity mismatch blocked: Coverage ${coverageAgent||'unknown'} · Confirmation ${confirmationAgent||'unknown'}. Reconnect from the current TrinoTime Agent session.`;
   else if(coverageConnected||confirmationConnected)$('status').textContent=`Coverage ${coverageConnected?'connected':'not connected'} · Confirmation ${confirmationConnected?'connected':'not connected'}.`;
  }
  return both;
 }catch(_){
  setConnectState(false);
  return false;
 }
}

(async()=>{
 try{
  const [tab]=await chrome.tabs.query({active:true,currentWindow:true});
  const r=tab?.id?await chrome.tabs.sendMessage(tab.id,{type:'tt-qc-mode'}):null;
  setMode(r?.mode||'none');
 }catch(_){setMode('ready');}
})();
Promise.allSettled([chrome.runtime.sendMessage({type:'cat-refresh-shift'}),chrome.runtime.sendMessage({type:'cft-refresh-shift'})]).finally(()=>refreshConnectionState().catch(()=>{}));

$('connect').onclick=async()=>{
 const button=$('connect');
 const wasConnected=button.dataset.connected==='true';
 button.disabled=true;
 $('status').textContent=wasConnected?'Refreshing both TrinoTime STAGING QA connections…':'Connecting Coverage and Confirmation to TrinoTime STAGING QA…';
 try{
  const a=await chrome.runtime.sendMessage({type:'cat-pair-trinotime'});if(!a?.ok)throw Error(a?.error||'Coverage connection failed');
  const b=await chrome.runtime.sendMessage({type:'cft-pair-trinotime'});if(!b?.ok)throw Error('STAGING QA Coverage connected. Confirmation: '+(b?.error||'connection failed'));
  await refreshConnectionState({announce:true});
 }catch(e){
  $('status').textContent=e.message;
  await refreshConnectionState({announce:false});
 }finally{
  button.disabled=false;
 }
};


const recoverButton=$('recoverShift');
if(recoverButton)recoverButton.onclick=async()=>{
 if(!confirm('Recover this active TrinoTime shift using your authenticated staging Agent account? This transfers ownership to the new Tracker and restores the server-recorded counts and jobs. Do not work in Augmoto during recovery. Unsubmitted local task/job work cannot be merged automatically. No shift reset will occur.'))return;
 recoverButton.disabled=true;$('status').textContent='Verifying identity and recovering Coverage and Confirmation…';
 try{
  const coverage=await chrome.runtime.sendMessage({type:'cat-recover-shift'});
  if(!coverage?.ok)throw new Error('Coverage recovery: '+(coverage?.error||'Failed.'));
  const confirmation=await chrome.runtime.sendMessage({type:'cft-recover-shift'});
  if(!confirmation?.ok)throw new Error('Coverage recovered. Confirmation recovery: '+(confirmation?.error||'Failed. You can retry safely.'));
  $('status').textContent='Shift recovered: both workflows restored without resetting server totals. ✓';
  await refreshConnectionState({announce:false});
 }catch(error){$('status').textContent=String(error.message||error);await refreshConnectionState({announce:false});}
 finally{recoverButton.disabled=false;}
};

const resetShiftButton=$('resetShift');
if(resetShiftButton)resetShiftButton.onclick=async()=>{
 if(resetShiftButton.disabled)return;
 if(!confirm('Reset Current Shift tracking? This clears the live Coverage + Confirmation counters for this active shift. The reset is recorded in TrinoTime audit history and does NOT Time Out the Agent.'))return;
 if(!confirm('Confirm Reset Current Shift? The current shift counters will restart from zero.'))return;
 resetShiftButton.disabled=true;$('status').textContent='Resetting current shift…';
 try{const r=await chrome.runtime.sendMessage({type:'cat-reset-current-shift'});if(!r?.ok)throw Error(r?.error||'Reset failed.');await chrome.runtime.sendMessage({type:'cft-refresh-shift'}).catch(()=>{});await chrome.runtime.sendMessage({type:'cat-refresh-shift'}).catch(()=>{});$('status').textContent='Current shift reset to zero. Reset was recorded in TrinoTime audit history.';}catch(e){$('status').textContent=e.message;}finally{await refreshConnectionState({announce:false});}
};

$('backup').onchange=async()=>{
 try{
  const file=$('backup').files[0];if(!file)return;if(file.size>20*1024*1024)throw Error('Backup is too large.');
  const r=await chrome.runtime.sendMessage({type:'cft-import-backup',backup:JSON.parse(await file.text())});
  if(!r?.ok)throw Error(r?.error||'Import failed');
  $('status').textContent='Confirmation history imported. Disable the separate Confirmation extension, then connect both trackers.';
  await refreshConnectionState({announce:false});
 }catch(e){$('status').textContent=e.message;}
};


const syncBothButton=$('syncBoth');
if(syncBothButton)syncBothButton.onclick=async()=>{
 const b=syncBothButton;b.disabled=true;$('status').textContent='Syncing Coverage and Confirmation…';
 try{
  const [coverage,confirmation]=await Promise.all([
   chrome.runtime.sendMessage({type:'cat-sync-now'}),
   chrome.runtime.sendMessage({type:'cft-sync-now'})
  ]);
  if(!coverage?.ok||!confirmation?.ok)throw Error(`Coverage: ${coverage?.error||'OK'} · Confirmation: ${confirmation?.error||'OK'}`);
  $('status').textContent='Coverage and Confirmation synced to TrinoTime STAGING QA ✓';
  await refreshConnectionState({announce:false});
 }catch(e){$('status').textContent=e.message;await refreshConnectionState({announce:false});}
 finally{b.disabled=false;}
};
if(typeof setInterval==='function')setInterval(()=>refreshConnectionState({announce:false}).catch(()=>{}),5000);
