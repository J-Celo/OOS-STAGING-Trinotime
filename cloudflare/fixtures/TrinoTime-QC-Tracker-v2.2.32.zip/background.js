importScripts('coverage-background.js', 'confirmation-background.js');
